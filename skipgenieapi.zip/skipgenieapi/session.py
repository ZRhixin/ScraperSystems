"""
Session management — stores JWT token, user_id, plan_id, and expiry.
Token lifetime is 24 hours per SkipGenie's JWT (exp - iat = 86400s).
"""
import json
import time
from pathlib import Path

SESSION_FILE = Path(__file__).parent / "session.json"
BUFFER_SECONDS = 300  # refresh 5 min before actual expiry


def save(token: str, expires_at: float, user_id: str = "", plan_id: str = "") -> None:
    SESSION_FILE.write_text(json.dumps({
        "token": token,
        "expires_at": expires_at,
        "user_id": user_id,
        "plan_id": plan_id,
    }))


def load() -> dict | None:
    if not SESSION_FILE.exists():
        return None
    data = json.loads(SESSION_FILE.read_text())
    if time.time() >= data["expires_at"] - BUFFER_SECONDS:
        return None
    return data


def get_token() -> str | None:
    data = load()
    return data["token"] if data else None
